import React from 'react';
import { FaTrash } from 'react-icons/fa';

const Resource = ({ resource, deleteResource }) => {
  return (
    <div className="resource">
      <span>{resource.name}</span>
      <FaTrash onClick={() => deleteResource(resource.id)} />
    </div>
  );
};

export default Resource;
