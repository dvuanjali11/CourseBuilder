import React, { useState } from 'react';

const AddModuleForm = ({ addModule }) => {
  const [moduleName, setModuleName] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (moduleName) {
      addModule(moduleName);
      setModuleName('');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="New Module Name"
        value={moduleName}
        onChange={(e) => setModuleName(e.target.value)}
      />
      <button type="submit">Add Module</button>
    </form>
  );
};

export default AddModuleForm;
