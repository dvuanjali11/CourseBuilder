import React, { useState } from 'react';

const AddResourceForm = ({ addResource }) => {
  const [resourceName, setResourceName] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (resourceName) {
      addResource({ name: resourceName });
      setResourceName('');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="New Resource Name"
        value={resourceName}
        onChange={(e) => setResourceName(e.target.value)}
      />
      <button type="submit">Add Resource</button>
    </form>
  );
};

export default AddResourceForm;
