import React from 'react';
import Resource from './Resource';

const Module = ({ module, addResource, deleteResource }) => {
  return (
    <div className="module">
      <h2>{module.name}</h2>
      <button onClick={() => addResource({}, module.id)}>Add Resource</button>
      <div className="module-resources">
        {module.resources.map(resource => (
          <Resource
            key={resource.id}
            resource={resource}
            deleteResource={deleteResource}
          />
        ))}
      </div>
    </div>
  );
};

export default Module;
