import React, { useState } from 'react';
import Module from './Module';
import AddModuleForm from './AddModuleForm';
import AddResourceForm from './AddResourceForm';
import './styles.css';

const App = () => {
  const [modules, setModules] = useState([]);
  const [resources, setResources] = useState([]);

  const addModule = (moduleName) => {
    setModules([...modules, { id: Date.now(), name: moduleName, resources: [] }]);
  };

  const addResource = (resource, moduleId = null) => {
    const newResource = { id: Date.now(), ...resource };
    if (moduleId) {
      setModules(modules.map(module => module.id === moduleId ? { ...module, resources: [...module.resources, newResource] } : module));
    } else {
      setResources([...resources, newResource]);
    }
  };

  const deleteResource = (resourceId) => {
    setResources(resources.filter(resource => resource.id !== resourceId));
    setModules(modules.map(module => ({ ...module, resources: module.resources.filter(resource => resource.id !== resourceId) })));
  };

  return (
    <div className="app">
      <h1>Course Builder</h1>
      <AddModuleForm addModule={addModule} />
      <AddResourceForm addResource={addResource} />
      <div className="modules">
        {modules.map(module => (
          <Module
            key={module.id}
            module={module}
            addResource={addResource}
            deleteResource={deleteResource}
          />
        ))}
      </div>
      <div className="resources">
        {resources.map(resource => (
          <Resource
            key={resource.id}
            resource={resource}
            deleteResource={deleteResource}
          />
        ))}
      </div>
    </div>
  );
};

export default App;
