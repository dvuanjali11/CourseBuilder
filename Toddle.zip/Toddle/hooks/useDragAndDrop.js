import { useDrag, useDrop } from 'react-dnd';

export const useDragAndDrop = (type, item, onDrop) => {
  const [, ref] = useDrag({
    type,
    item,
  });

  const [, drop] = useDrop({
    accept: type,
    drop: onDrop,
  });

  return [ref, drop];
};
